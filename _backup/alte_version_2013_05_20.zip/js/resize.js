 // Navigator 4.x neuladen bei resize
function handleResize() 
 {
   if (window.prevWidth != window.innerWidth || 
       window.prevHeight != window.innerHeight) 
   {
     history.go(0);
     return false;
   }
 }

 if (navigator.appName.indexOf("Netscape") >= 0 &&  
     parseInt(navigator.appVersion) == 4)
 {
   window.prevWidth = window.innerWidth;
   window.prevHeight = window.innerHeight;
   window.captureEvents(Event.RESIZE);
   window.onresize = handleResize;
 } // Navigator 4.x neuladen bei resize
function handleResize() 
 {
   if (window.prevWidth != window.innerWidth || 
       window.prevHeight != window.innerHeight) 
   {
     history.go(0);
     return false;
   }
 }

 if (navigator.appName.indexOf("Netscape") >= 0 &&  
     parseInt(navigator.appVersion) == 4)
 {
   window.prevWidth = window.innerWidth;
   window.prevHeight = window.innerHeight;
   window.captureEvents(Event.RESIZE);
   window.onresize = handleResize;
 }