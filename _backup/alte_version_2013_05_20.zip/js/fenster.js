
  function fenster() {
  var win;
		win=window.open("anfahrt.htm","fenster","width=440,height=450,scrollbars=no,toolbar=yes,resizable=no,screenX=0,screenY=0");
		win.focus();
  	} 
	
  function fenster1() {
  var win;
		win=window.open("anmkiga.htm","fenster","width=560,height=500,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win.focus();
  	}  
	
  function fenster2() {
  var win;
		win=window.open("anmkikr.htm","fenster","width=550,height=500,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win.focus();
  	}  
	
  function fenster3() {
  var win;
		win=window.open("merkfroe.htm","fenster","width=530,height=500,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win.focus();
  	}  
	
  function fenster4() {
  var win4;
		win4=window.open("merkqua.htm","fenster","width=540,height=500,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win4.focus();
  	}  
	
  function fenster5() {
  var win5;
		win5=window.open("artikel1.htm","fenster","width=550,height=400,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win5.focus();
  	}  
	
  function fenster6() {
  var win6;
		win6=window.open("artikel2.htm","fenster","width=550,height=400,scrollbars=yes,toolbar=yes,resizable=yes,screenX=0,screenY=0");
		win6.focus();
  	}  
	
  function fenster7() {
  var win7;
		win7=window.open("misch.htm","fenster","width=520,height=480,scrollbars=no,toolbar=no,resizable=no,screenX=0,screenY=0");
		win7.focus();
  	}  
	
  function fenster8() {
  var win8;
		win8=window.open("kreativ.htm","fenster","width=520,height=480,scrollbars=no,toolbar=no,resizable=no,screenX=0,screenY=0");
		win8.focus();
  	}  
	
  function fenster9() {
  var win9;
		win9=window.open("raum.htm","fenster","width=520,height=480,scrollbars=no,toolbar=no,resizable=no,screenX=0,screenY=0");
		win9.focus();
  	}  

  function fenster10() {
  var win10;
		win10=window.open("hilfe.htm","fenster","width=430,height=300,scrollbars=no,toolbar=no,resizable=no,screenX=0,screenY=0");
		win10.focus();
  	}  
	
  function fenster14() {
  var win;
		win=window.open("history.htm","fenster","width=550,height=500,scrollbars=yes,toolbar=no,resizable=no,screenX=0,screenY=0");
		win.focus();
  	}  	
	
  function fenster15() {
  var win;
		win=window.open("eintrag.php","fenster","width=620,height=500,scrollbars=yes,toolbar=no,resizable=no,screenX=0,screenY=0");
		win.focus();
  	} 

  function fenster16() {
  var win;
		win=window.open("kovor.htm","fenster","width=370,height=500,scrollbars=yes,toolbar=no,resizable=no,screenX=0,screenY=0");
		win.focus();
  	} 
	
  function fenster17() {
  var win;
		win=window.open("koakt.htm","fenster","width=370,height=500,scrollbars=yes,toolbar=no,resizable=no,screenX=0,screenY=0");
		win.focus();
  	}
	
  function fenster18() {
  var win;
		win=window.open("konae.htm","fenster","width=370,height=500,scrollbars=yes,toolbar=no,resizable=no,screenX=0,screenY=0");
		win.focus();
  	}  
	
  function fenster19() {
  var win;
		win=window.open("eltern.htm","fenster","width=500,height=500,scrollbars=yes,toolbar=no,resizable=yes,screenX=0,screenY=0");
		win.focus();
  	}  