<!--Einbindung der CSS-Dateien//-->

       if (navigator.appVersion.indexOf("Mac") != -1)
	   
       	{	
		if ((navigator.appVersion.indexOf("MSIE") != -1) && (navigator.appVersion.indexOf("5.0") != -1)) {
					document.write("<LINK REL=stylesheet HREF=\"../../css/macie.css\" TYPE=\"text/css\">");
			}	
			
			else {
			if (navigator.userAgent.indexOf("Netscape6") != -1)
					{	
					document.write("<LINK REL=stylesheet HREF=\"../../css/mac.css\" TYPE=\"text/css\">");
					}
					
			else {	document.write("<LINK REL=stylesheet HREF=\"../../css/mac.css\" TYPE=\"text/css\">");
       
	   }
	   }
	   }
	   else
       if ((navigator.appVersion.indexOf("Win") != -1) && (navigator.appVersion.indexOf("MSIE") != -1))
	   {
					document.write("<LINK REL=stylesheet HREF=\"../../css/winie.css\" TYPE=\"text/css\">");
		}
					
       else			document.write("<LINK REL=stylesheet HREF=\"../../css/win.css\" TYPE=\"text/css\">");