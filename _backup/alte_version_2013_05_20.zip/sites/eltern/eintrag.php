<html>
<head>
<title>Meckerecke Eintr&auml;ge</title>
</head>
<script language="JavaScript" src="../../js/css.js" type="text/javascript"></script>
<body bgcolor="#C1F6A3">
<table width="100" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="../../images/blindgif.gif" width="10" height="20"></td>
    <td><img src="../../images/blindgif.gif" width="200" height="20"></td>
  </tr>
  <tr>
  	<td>&nbsp;</td>
    <td><em class="head1black">Hier nun alle Eintr&auml;ge:</em></td>
  </tr>
</table>
<p>
<?
//lesen

$filename = "gbook.txt";
if(file_exists($filename)){
	$file = fopen($filename, "r");
	if($file){
	    //zeilenweise durchlesen, in $zeile steht immer der aktuelle string(zeile) drin
		while($zeile = fgets($file,255)){ 
			echo $zeile . "\n";
		
		}
	}
}
?>
<table width="100" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><img src="../../images/blindgif.gif" width="600" height="10"></td>
  </tr>
  <tr> 
    <td height="20" align="right"><a href="#" onClick="self.close()">Fenster schlie&szlig;en</a></td>
  </tr>
  <tr> 
    <td><img src="../../images/blindgif.gif" width="600" height="10"></td>
  </tr>
</table>
</body>
</html>
