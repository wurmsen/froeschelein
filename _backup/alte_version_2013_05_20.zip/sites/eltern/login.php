<html>
<head>
<title>Elterninitiative Die Fr&ouml;schelein e.V. - Elternseite</title>

</head>
<script language="JavaScript" src="../../js/css.js" type="text/javascript"></script>
<script language="JavaScript" src="../../js/fenster.js" type="text/javascript"></script>
<body bgcolor="#C1F6A3">
<?
$err_msg="";
if (isset($submit) && ($REQUEST_METHOD=="POST")){
	//einloginfos in array anlegen
	$liste = array ("lena11"=>"buehring","anna12"=>"wittig","sophia13"=>"baeumler","rebecca14"=>"block","lm96"=>"boser","tobias10"=>"felser","agatha17"=>"walkowski","pia22"=>"freilinger","adrian15"=>"starfinger","florian16"=>"enderle","marco99"=>"pannars","katharina9"=>"keck","mathias33"=>"jackermei","alwin18"=>"frings","maya28"=>"mielke","mateo81"=>"flohr","elisabeth7"=>"horban");
	//login-namen in $liste suchen
	$suche = array_search($login, $liste);

	if ($suche != $pass){
		unset($submit);
		unset($login);
		unset($pass);
		echo "<br><br><br><p align=center class=head1black>Ihre Anmeldung war leider nicht korrekt.<br>Vielleicht haben Sie sich nur vertippt.<br>Probieren Sie es nocheinmal.</em><br><br><img src='../../images/themen/kopf.gif'></p><p align=center><a href=login.php>neu Anmelden</a></p>";
	}elseif($suche == $pass){
		echo "<meta http-equiv=refresh content='0; URL=info.htm'>";
		unset($submit);
		unset($login);
		unset($pass);
	}
}else{	
	if (isset($submit) && ($REQUEST_METHOD=="POST")){
		print "<p>falsch gelaufen</p>";
	}
	
echo $err_msg;
?>

<!-- hier kommt der abfrageteil -->
<form name="form1" action="<? echo $PHP_SELF; ?>" method="post">
  <table width="436" border="0" cellspacing="0" cellpadding="0">
    <tr>
    <td rowspan="2"><img src="../../images/blindgif.gif" width="130" height="120"></td>
    <td colspan="2"><img src="../../images/blindgif.gif" width="300" height="60"></td>
  </tr>
  <tr>
     <td colspan="2"><em class="head1black">
	Die Elternseiten sind gesch�tzt und k�nnen nur von Fr�schelein-Eltern besucht werden!</em></td>
  </tr>
</table>
  <table border="0" valign="middle">
    <tr> 
      <td><img src="../../images/blindgif.gif" width="170" height="20"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><em class="head">Login</em></td>
      <td> 
        <input type="text" name="login" size="10" maxlength="10">
      </td>
    </tr>
    <tr> 
      <td height="29">&nbsp;</td>
      <td height="29"><em class="head">Passwort</em></td>
      <td height="29"> 
        <input type="password" name="pass" size="10" maxlength="10">
      </td>
    </tr>
    <tr> 
	   <td>&nbsp;</td>
      <td colspan="2" align="center"> 
        <input type="submit" name="submit" value="anmelden">
      </td>
    </tr>
  </table>
</form>
<?
}
?>
</body>
</html>
