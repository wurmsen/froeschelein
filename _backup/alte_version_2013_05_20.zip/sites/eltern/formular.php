<html>
<head>
<title>Meckerecke</title>
</head>
<script Language="JavaScript" src="../../js/css.js" type="text/javascript"></script>
<script Language="JavaScript" src="../../js/fenster.js" type="text/javascript"></script>
<script Language="JavaScript">
<!--
function declarieren() {
	myElement = window.document.forms[0].elements;
	meldung = window.alert;
}


function leeren(){
	window.document.forms[0].elements["name"].value = "";
	window.document.forms[0].elements["text"].value = "";
}

function formCheck(){
	if(myElement["name"].value == "") {
		meldung("Bitte geben Sie einen Namen ein!\nEs kann auch ein fiktiver Name sein.");
		myElement["name"].focus();
		return false;
	}
	
	if(myElement["text"].value == "") {
		meldung("Bitte geben Sie einen Text ein!");
		myElement["text"].focus();
		return false;
	}
	return true;
}
//-->
</script>
<body bgcolor="#C1F6A3" onload="declarieren()">

<?
//init
$filename = "gbook.txt";
$zeit = time(); 
$datum = getdate($zeit);
//schreiben wenn variable name existiert und name nicht leer ist
if (isset($name) && $name != ""){
	$file = fopen($filename, "a"); //datei vorher anlegen und permissens vergeben
	if($file){
		$input = "<em class='normblack'>&nbsp;<u>$name</u>:&nbsp; $datum[mday]. $datum[month] $datum[year] ($datum[hours]:$datum[minutes] Uhr)<br></em>&nbsp;&nbsp;<em class='norm'>$text</em><hr>\n";
		fputs($file, $input);
		fclose($file);
	}
}
?>
<form method="post" onSubmit="return formCheck()">
  <table border="0" cellspacing="0" width="200" height="50">
    <tr> 
      <td><img src="../../images/blindgif.gif" width="20" height="20"></td>
      <td><img src="../../images/blindgif.gif" width="50" height="20"></td>
      <td><img src="../../images/blindgif.gif" width="500" height="20"></td>
    <tr> 
      <td><img src="../../images/blindgif.gif" width="20" height="40"></td>
      <td>&nbsp;</td>
      <td valign="top"><em class="head1black">Hier Namen und Text eintragen und abschicken!</em></td>
    <tr> 
      <td>&nbsp;</td>
      <td valign="top"><em class="head1black">Name:</em></td>
      <td valign="top"><em class="norm"><input type="text" name="name" size="20">
	  </em></td>
    </tr>
    <tr> 
      <td><img src="../../images/blindgif.gif" width="20" height="10"></td>
      <td><img src="../../images/blindgif.gif" width="40" height="10"></td>
      <td><img src="../../images/blindgif.gif" width="300" height="10"></td>
    </tr>
    <tr> 
      <td><img src="../../images/blindgif.gif" width="20" height="130"></td>
      <td valign="top"><em class="head1black">Text:</em></td>
      <td valign="top"><em class="norm"><textarea name="text" cols="50" rows="10"></textarea>
        </em> </td>
    </tr>
    <tr> 
      <td height="35">&nbsp;</td>
      <td>&nbsp;</td>
      <td valign="bottom"> 
        <input type="image" src="../../images/buttons/eintrag.jpg" width="90" height="25" alt="eintragen" border="0" name="image">
        <a href="#" onClick="leeren()"><img border="0" src="../../images/buttons/leeren.jpg" width="90" height="25"></a> 
      </td>
    </tr>
  </table>
  
  <table width="100" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td><img src="../../images/blindgif.gif" width="300" height="10"></td>
      <td><img src="../../images/blindgif.gif" width="150" height="10"></td>
      <td><img src="../../images/blindgif.gif" width="40" height="10"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><a href='javascript:fenster15()'>zu den Eintr&auml;gen</a></td>
      <td><a href="mecker.htm">zur&uuml;ck</a></td>
    </tr>
  </table>
</form>
</body>
</html>
